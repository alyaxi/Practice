with open('demo.txt') as fileObj:
    for line in fileObj:
        print(line)