print("Pakistan zinda bad")
print(2+7)
print('End Code Result')