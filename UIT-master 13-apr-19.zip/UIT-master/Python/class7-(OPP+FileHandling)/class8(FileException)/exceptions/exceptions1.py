print("First")
a = 10
b = 5
try:
    c = a/b
    print(c)
except ZeroDivisionError:
    print("Handle ZeroDivisionError")


print("last")

