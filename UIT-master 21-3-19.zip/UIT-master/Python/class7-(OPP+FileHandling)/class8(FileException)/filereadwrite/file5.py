
with open('demo1.txt','a') as fileObj:
    fileObj.write("\n Hello World2")