import  os;

p = os.path.isfile("demo.txt")
p1 = os.path.isdir("C:\\Windows")
dirList = os.listdir("C:\\Windows")
print(p)
print(p1)
print(dirList)